IMG_EXTENSIONS = ('.png', '.jpg', '.jpeg')
